# Pascal MCP

This bundle contains the Pascal MCP server and the RAD Studio skills for Codex, Claude Code, and Cursor.

## Contents

- `server/` — Pascal MCP source at commit `76fa536`.
- `codex/.agents/skills/` — project-ready Codex skills.
- `claude/.claude/skills/` — project-ready Claude Code skills.
- `cursor/.cursor/skills/` — project-ready Cursor skills.
- Each client folder includes an MCP configuration example.

## Requirements

- Windows with RAD Studio or Delphi for Delphi builds.
- Python 3.11 or newer.
- `uv`, which provides `uvx`.

## Codex

Copy the contents of `codex/.agents/skills/` into your repository's `.agents/skills/` folder. For user-wide installation, copy the two skill folders into `~/.agents/skills/`.

Merge `codex/config.toml.example` into `~/.codex/config.toml`, then restart Codex.

## Claude Code

Copy the contents of `claude/.claude/skills/` into your repository's `.claude/skills/` folder. For user-wide installation, copy the two skill folders into `~/.claude/skills/`.

Register the server with the command below, or merge `claude/.mcp.json.example` into the project's `.mcp.json` file:

```bash
claude mcp add --transport stdio pascal-mcp -- uvx --from git+https://github.com/tina4stack/pascal-mcp pascal-mcp
```

## Cursor

Copy the contents of `cursor/.cursor/skills/` into your repository's `.cursor/skills/` folder. For user-wide installation, copy the two skill folders into `~/.cursor/skills/`.

Merge `cursor/.cursor/mcp.json.example` into `.cursor/mcp.json` for project use or `~/.cursor/mcp.json` for user-wide use. Restart Cursor after the change.

## Verify

Ask the client to call `mcp__pascal_mcp__get_compiler_info`. Do not edit or build Delphi code until the server reports the required compiler and target toolchain.

## Repository

https://github.com/tina4stack/pascal-mcp
